# DIDE (DIfferentiated Desktop Environment)

## Settings

> The `/etc/xdg/` and the default configuration folder.


# Learn more at these links:

- [Scripts Shell sob Controle](http://www.mhavila.com.br/topicos/unix/shscript.html)
- [Daemons](https://www.gbzando.com.br/daemons/)
